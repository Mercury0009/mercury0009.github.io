<?php include 'header.php'; ?>

   <div class="grid_4">
		<div class="container"> 
			<h1 class="blog_head">Статьи ДАННЫЙ БЛОГ СЛУЖИТ ДЛЯ ПРИВЛЕЧЕНИЯ ТРАФИКА ИЗ СЕТИ</h1>
		   <div class="blog_grid span2">
		     <div class="col-md-6 blog_box">
		        <a href="single.html" class="mask"><img src="images/b1.jpg" alt="image" class="img-responsive zoom-img" alt=""/></a>
		     	<h3><a href="single.html">Статьи о перевозке топлива по железной дороге</a></h3>
		     	<div class="links">
		  		    <ul>
		  				<li><i class="fa blog-icon fa-calendar"> </i><span>june 14, 2013</span></li>
		  				<li><i class="fa blog-icon fa-user"> </i><span>admin</span></li>
		  				<li><i class="fa blog-icon fa-comment"> </i><a href="#"><span>No comments</span></a></li>
		  		    </ul>
		  		</div>
		     	<p>Здесь мы расскажем что нужно сделать, чтобы правильно перевести груз по железной дороге. Первый заголовок, показыает, что в статье описано...</p>
		        <a href="#" class="btn1 btn-8 btn-8c">Прочитать дальше</a>
		     </div>  
		     <div class="col-md-6 blog_box">
		        <a href="single.html" class="mask"><img src="images/b2.jpg" alt="image" class="img-responsive zoom-img" alt=""/></a>
		     	<h3><a href="single.html">Вторая статья о том, как правильно оформлять сделки</a></h3>
		     	<div class="links">
		  		    <ul>
		  				<li><i class="fa blog-icon fa-calendar"> </i><span>june 14, 2013</span></li>
		  				<li><i class="fa blog-icon fa-user"> </i><span>admin</span></li>
		  				<li><i class="fa blog-icon fa-comment"> </i><a href="#"><span>No comments</span></a></li>
		  		    </ul>
		  		</div>
		     	<p>Тоже самое, какая-нибудь статья о том, как же все таки нужно правильно оформлять сделки и не допустить страшные ошибки</p>
		        <a href="#" class="btn1 btn-8 btn-8c">Прочитать дальше...</a>
		     </div>  
		     <div class="clearfix"> </div>
		   </div>
		    <div class="blog_grid">
		     <div class="col-md-6 blog_box">
		        <a href="single.html" class="mask"><img src="images/b3.jpg" alt="image" class="img-responsive zoom-img" alt=""/></a>
		     	<h3><a href="single.html">Еще статья на какую-нибудь тему</a></h3>
		     	<div class="links">
		  		    <ul>
		  				<li><i class="fa blog-icon fa-calendar"> </i><span>june 14, 2013</span></li>
		  				<li><i class="fa blog-icon fa-user"> </i><span>admin</span></li>
		  				<li><i class="fa blog-icon fa-comment"> </i><a href="#"><span>No comments</span></a></li>
		  		    </ul>
		  		</div>
		     	<p>Первый абзац статьи...</p>
		        <a href="#" class="btn1 btn-8 btn-8c">Прочитать дальше...</a>
		     </div>  
		     <div class="col-md-6 blog_box">
		        <a href="single.html" class="mask"><img src="images/b4.jpg" alt="image" class="img-responsive zoom-img" alt=""/></a>
		     	<h3><a href="single.html">Ut wisi enim ad minim veniam, quis nostrud exerc</a></h3>
		     	<div class="links">
		  		    <ul>
		  				<li><i class="fa blog-icon fa-calendar"> </i><span>june 14, 2013</span></li>
		  				<li><i class="fa blog-icon fa-user"> </i><span>admin</span></li>
		  				<li><i class="fa blog-icon fa-comment"> </i><a href="#"><span>No comments</span></a></li>
		  		    </ul>
		  		</div>
		     	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam,nibh euismod tincidunt</p>
		        <a href="#" class="btn1 btn-8 btn-8c">Read More</a>
		     </div>  
		   </div>
		   <div class="pagination">
		    <ul><li class="pagination-start firstItem"><span class="pagenav">Start</span></li>
		    	<li class="pagination-prev"><span class="pagenav">Prev</span></li><li>
		    	<span class="pagenav">1</span></li><li><a href="#" class="pagenav">2</a></li>
		    	<li class="pagination-next"><a title="" href="#" class="border pagenav" data-original-title="Next">Next</a></li>
		    	<li class="pagination-end lastItem"><a title="" href="#" class="border pagenav" data-original-title="End">End</a></li>
		    </ul>	
		  </div>
	   </div>
	</div>
	 <?php include 'footer.php'; ?>	