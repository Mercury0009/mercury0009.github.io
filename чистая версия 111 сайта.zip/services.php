<?php include 'header.php'; ?>

   <div class="grid_4">
		<div class="container"> 
		       <div class="about-grids service_box">
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic12.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Бензин</a></h3>
							<p class="service_desc">Текст о бензине</p>
						</div>
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic13.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Дизельное топливо/a></h3>
							<p class="service_desc">о дизельном топливе</p>
						</div>
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic15.jpg" class="img-responsive" alt=""/></a>
                             </div>
							<br>
							<h3><a href="benz.html">Топливные карты</a></h3>
							<p class="service_desc">о картах</p>
						</div>
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic8.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Битум/a></h3>
							<p class="service_desc">о битуме.</p>
						</div>
				        <div class="clearfix"> </div>
	           </div>
	           <div class="about-grids service_box">
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic14.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Мазут</a></h3>
							<p class="service_desc">О мазуте</p>
						</div>
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic16.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Нефтехимия</a></h3>
							<p class="service_desc">о нефтехимии</p>
						</div>
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic17.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Масла</a></h3>
							<p class="service_desc">Масла и их различия.</p>
						</div>
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic18.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Транспортировка топлива</a></h3>
							<p class="service_desc">Про транспортирвоку топлива.</p>
						</div>
				        <div class="clearfix"> </div>
	           </div>
	           <div class="about-grids">
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic9.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Крупный опт</a></h3>
							<p class="service_desc">Крупный опт.</p>
						</div>
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic10.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Расчет жд тарифов</a></h3>
							<p class="service_desc">Ссылка на жд тарифы.</p>
						</div>
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic11.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Еще что-инубдь</a></h3>
							<p class="service_desc">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
						</div>
						<div class="col-sm-3 about-gridz">
							
						    <div class="view view-first">
                              <a href="benz.html"><img src="images/pic19.jpg" class="img-responsive" alt=""/></a>
                            </div>
							<br>
							<h3><a href="benz.html">Еще что-инубдь</a></h3>
							<p class="service_desc">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
						</div>
				        <div class="clearfix"> </div>
	          </div>
	   </div>
	</div>
	 <?php include 'footer.php'; ?>