<?php include 'header.php'; ?>

	<div class="grid_1">
	   <div class="container">
		  <div class="box_1">
			<h3>Страница посвященная бензину</h3>
		  </div>
		  <div class="col-md-12 about_banner"><img src="images/about.jpg" class="img-responsive" alt=""/></div>
		  <div class="box_20">
			  <div class="col-sm-12">
			  	<p>Описание, что же такое этот бензин </p>
			  	<p>Описание, что же такое этот бензин </p>
			  	<p>Описание, что же такое этот бензин </p>
			  	<p>Описание, что же такое этот бензин </p>
			  	<p>Описание, что же такое этот бензин </p>
			  	<p>Описание, что же такое этот бензин </p>
			  	<p>Описание, что же такое этот бензин </p>
			  	<p>Описание, что же такое этот бензин </p>
			  	<p>Описание, что же такое этот бензин </p>
			  	<p>Описание, что же такое этот бензин </p>
			  </div>
			  
		      <div class="clearfix"> </div>
		  </div>
	   </div>
	</div>


    <?php include 'footer.php'; ?>