	<div class="footer wow fadeInRight" data-wow-delay="0.4s">
		<div class="container">
		  <div class="footer_top">
			<div class="col-sm-3">
			   <ul class="list1">
			   	<h3>Browse</h3>
			   	 <li><a href="#">Industrial Resources</a></li>
			   	 <li><a href="#">Jobs</a></li>
			   	 <li><a href="#">Buildings</a></li>
			     <li><a href="#">Contacts</a></li>
			   </ul>
			</div>
			<div class="col-sm-3">
			  <ul class="list1">
			    <h3>Services</h3>
			   	 <li><a href="#">Communications</a></li>
			   	 <li><a href="#">Electrical</a></li>
			   	 <li><a href="#">Industrial</a></li>
			   	 <li><a href="#">Mechanical</a></li>
			  </ul>
			</div>
			<div class="col-sm-3">
			  <ul class="list1">
			  	<h3>Navigation</h3>
			   	 <li><a href="#">About Us</a></li>
			   	 <li><a href="#">Apply</a></li>
			   	 <li><a href="#">Terms and Conditions</a></li>
			   	 <li><a href="#">Register</a></li>
			  </ul>
			</div>
			<div class="col-sm-3">
			  <ul class="socials">
                 <li><a href="#"><i class="fa fb fa-facebook"></i></a></li>
                 <li><a href="#"><i class="fa tw fa-twitter"></i></a></li>
              </ul>
              <ul class="list2">
				<li><strong class="phone">+7(995)995-95-95</strong><br><small>Пн - Пт / 9.00 - 18.00</small></li>
				<li>Вопросы? <a href="malito:info@mobilehome.group">info@mobilehome.group</a></li>
			  </ul>
			</div>
			<div class="clearfix"> </div>
		   </div>
		 </div>
	</div>
	<div class="copy">
	  <p>Copyright &copy; 2020.  Все права защищены. </p>
    </div>
</body>
</html>		