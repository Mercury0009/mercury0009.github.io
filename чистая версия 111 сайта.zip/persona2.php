<?php include 'header.php'; ?>

   <div class="grid_4">
		<div class="container"> 
			<h1 class="blog_head">Дядя Сережа</h1>
		   <div class="blog_grid span2">
		     <div class="col-md-6 blog_box">
		        <a href="single.html" class="mask"><img src="images/b1.jpg" alt="image" class="img-responsive zoom-img" alt=""/></a>
		     	<h3><a href="single.html">ФИО, 1965г</a></h3>
		     
		
		     </div>  
		     <div class="col-md-6 blog_box">
		        
		     	
		    
		     	<p>Описание заслуг человека перед компанией</p>
		     	<p>Описание заслуг человека перед компанией</p>
		     	<p>Описание заслуг человека перед компанией</p>
		     	<p>Описание заслуг человека перед компанией</p>
		     	<p>Описание заслуг человека перед компанией</p>
		     	<p>Описание заслуг человека перед компанией</p>
		     	<p>Описание заслуг человека перед компанией</p>
		     	<p>Описание заслуг человека перед компанией</p>
		     	<p>Описание заслуг человека перед компанией</p>
		        
		     </div>  
		     <div class="clearfix"> </div>
		   </div>
		   

	   </div>
	</div>
	 <?php include 'footer.php'; ?>	